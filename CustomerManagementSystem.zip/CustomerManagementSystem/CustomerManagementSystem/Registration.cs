﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerManagementSystem
{
    class Registration
    {
        public Registration()
        {

        }
        public int CustomerID { get; set; }

        public int ProductCode { get; set; }

        public DateTime RegistrationDate { get; set; }


    }
}
