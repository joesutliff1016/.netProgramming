﻿namespace CustomerManagementSystem
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.cboBoxCustomer = new System.Windows.Forms.ComboBox();
            this.customersBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.techSupportDataSet3 = new CustomerManagementSystem.TechSupportDataSet();
            this.customersBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.techSupportDataSet = new CustomerManagementSystem.TechSupportDataSet();
            this.label2 = new System.Windows.Forms.Label();
            this.cboBoxProduct = new System.Windows.Forms.ComboBox();
            this.productsBindingSource17 = new System.Windows.Forms.BindingSource(this.components);
            this.techSupportDataSet2 = new CustomerManagementSystem.TechSupportDataSet();
            this.productsBindingSource19 = new System.Windows.Forms.BindingSource(this.components);
            this.techSupportDataSet4 = new CustomerManagementSystem.TechSupportDataSet();
            this.productsBindingSource16 = new System.Windows.Forms.BindingSource(this.components);
            this.productsBindingSource14 = new System.Windows.Forms.BindingSource(this.components);
            this.productsBindingSource13 = new System.Windows.Forms.BindingSource(this.components);
            this.productsBindingSource12 = new System.Windows.Forms.BindingSource(this.components);
            this.techSupportDataSet1 = new CustomerManagementSystem.TechSupportDataSet();
            this.productsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.techSupportDataSetBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.productsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.txtRegDate = new System.Windows.Forms.TextBox();
            this.btnRegister = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.techSupportDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.techSupportDataSetBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.productsTableAdapter = new CustomerManagementSystem.TechSupportDataSetTableAdapters.ProductsTableAdapter();
            this.techSupportDataSetBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.techSupportDataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.productsBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.productsBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.productsBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.fKIncidentsProductsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.incidentsTableAdapter = new CustomerManagementSystem.TechSupportDataSetTableAdapters.IncidentsTableAdapter();
            this.techSupportDataSet1BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.productsBindingSource6 = new System.Windows.Forms.BindingSource(this.components);
            this.productsBindingSource7 = new System.Windows.Forms.BindingSource(this.components);
            this.productsBindingSource8 = new System.Windows.Forms.BindingSource(this.components);
            this.productsBindingSource9 = new System.Windows.Forms.BindingSource(this.components);
            this.productsBindingSource10 = new System.Windows.Forms.BindingSource(this.components);
            this.productsBindingSource11 = new System.Windows.Forms.BindingSource(this.components);
            this.techSupportDataSet1BindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.customersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customersTableAdapter = new CustomerManagementSystem.TechSupportDataSetTableAdapters.CustomersTableAdapter();
            this.productsBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.techSupportDataSetBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.customersBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.productsBindingSource15 = new System.Windows.Forms.BindingSource(this.components);
            this.productsBindingSource18 = new System.Windows.Forms.BindingSource(this.components);
            this.customersBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.btnAddCustomer = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSetBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSetBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSetBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSet1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKIncidentsProductsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSet1BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSet1BindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSetBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource4)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer:";
            // 
            // cboBoxCustomer
            // 
            this.cboBoxCustomer.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.customersBindingSource3, "CustomerID", true));
            this.cboBoxCustomer.DataSource = this.customersBindingSource1;
            this.cboBoxCustomer.DisplayMember = "Name";
            this.cboBoxCustomer.FormattingEnabled = true;
            this.cboBoxCustomer.Location = new System.Drawing.Point(75, 10);
            this.cboBoxCustomer.Name = "cboBoxCustomer";
            this.cboBoxCustomer.Size = new System.Drawing.Size(121, 21);
            this.cboBoxCustomer.TabIndex = 1;
            this.cboBoxCustomer.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // customersBindingSource3
            // 
            this.customersBindingSource3.DataMember = "Customers";
            this.customersBindingSource3.DataSource = this.techSupportDataSet3;
            // 
            // techSupportDataSet3
            // 
            this.techSupportDataSet3.DataSetName = "TechSupportDataSet";
            this.techSupportDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customersBindingSource1
            // 
            this.customersBindingSource1.DataMember = "Customers";
            this.customersBindingSource1.DataSource = this.techSupportDataSet;
            // 
            // techSupportDataSet
            // 
            this.techSupportDataSet.DataSetName = "TechSupportDataSet";
            this.techSupportDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Product:";
            // 
            // cboBoxProduct
            // 
            this.cboBoxProduct.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.productsBindingSource17, "ProductCode", true));
            this.cboBoxProduct.DataSource = this.productsBindingSource19;
            this.cboBoxProduct.DisplayMember = "Name";
            this.cboBoxProduct.FormattingEnabled = true;
            this.cboBoxProduct.Location = new System.Drawing.Point(75, 38);
            this.cboBoxProduct.Name = "cboBoxProduct";
            this.cboBoxProduct.Size = new System.Drawing.Size(121, 21);
            this.cboBoxProduct.TabIndex = 3;
            this.cboBoxProduct.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // productsBindingSource17
            // 
            this.productsBindingSource17.DataMember = "Products";
            this.productsBindingSource17.DataSource = this.techSupportDataSet2;
            // 
            // techSupportDataSet2
            // 
            this.techSupportDataSet2.DataSetName = "TechSupportDataSet";
            this.techSupportDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productsBindingSource19
            // 
            this.productsBindingSource19.DataMember = "Products";
            this.productsBindingSource19.DataSource = this.techSupportDataSet4;
            // 
            // techSupportDataSet4
            // 
            this.techSupportDataSet4.DataSetName = "TechSupportDataSet";
            this.techSupportDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productsBindingSource16
            // 
            this.productsBindingSource16.DataMember = "Products";
            this.productsBindingSource16.DataSource = this.techSupportDataSet2;
            // 
            // productsBindingSource14
            // 
            this.productsBindingSource14.DataMember = "Products";
            this.productsBindingSource14.DataSource = this.techSupportDataSet;
            // 
            // productsBindingSource13
            // 
            this.productsBindingSource13.DataMember = "Products";
            this.productsBindingSource13.DataSource = this.techSupportDataSet;
            // 
            // productsBindingSource12
            // 
            this.productsBindingSource12.DataMember = "Products";
            this.productsBindingSource12.DataSource = this.techSupportDataSet1;
            // 
            // techSupportDataSet1
            // 
            this.techSupportDataSet1.DataSetName = "TechSupportDataSet";
            this.techSupportDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productsBindingSource
            // 
            this.productsBindingSource.DataMember = "Products";
            this.productsBindingSource.DataSource = this.techSupportDataSetBindingSource2;
            // 
            // techSupportDataSetBindingSource2
            // 
            this.techSupportDataSetBindingSource2.DataSource = this.techSupportDataSet;
            this.techSupportDataSetBindingSource2.Position = 0;
            // 
            // productsBindingSource1
            // 
            this.productsBindingSource1.DataMember = "Products";
            this.productsBindingSource1.DataSource = this.techSupportDataSet;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Reg date:";
            // 
            // txtRegDate
            // 
            this.txtRegDate.Location = new System.Drawing.Point(75, 66);
            this.txtRegDate.Name = "txtRegDate";
            this.txtRegDate.Size = new System.Drawing.Size(100, 20);
            this.txtRegDate.TabIndex = 5;
            this.txtRegDate.TextChanged += new System.EventHandler(this.txtRegDate_TextChanged);
            // 
            // btnRegister
            // 
            this.btnRegister.Location = new System.Drawing.Point(12, 114);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(112, 23);
            this.btnRegister.TabIndex = 6;
            this.btnRegister.Text = "Register Product";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(141, 114);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(238, 114);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.button3_Click);
            // 
            // techSupportDataSetBindingSource
            // 
            this.techSupportDataSetBindingSource.DataSource = this.techSupportDataSet;
            this.techSupportDataSetBindingSource.Position = 0;
            // 
            // techSupportDataSetBindingSource1
            // 
            this.techSupportDataSetBindingSource1.DataSource = this.techSupportDataSet;
            this.techSupportDataSetBindingSource1.Position = 0;
            // 
            // productsTableAdapter
            // 
            this.productsTableAdapter.ClearBeforeFill = true;
            // 
            // techSupportDataSetBindingSource3
            // 
            this.techSupportDataSetBindingSource3.DataSource = this.techSupportDataSet;
            this.techSupportDataSetBindingSource3.Position = 0;
            // 
            // techSupportDataSet1BindingSource
            // 
            this.techSupportDataSet1BindingSource.DataSource = this.techSupportDataSet1;
            this.techSupportDataSet1BindingSource.Position = 0;
            // 
            // productsBindingSource2
            // 
            this.productsBindingSource2.DataMember = "Products";
            this.productsBindingSource2.DataSource = this.techSupportDataSet1;
            // 
            // productsBindingSource3
            // 
            this.productsBindingSource3.DataMember = "Products";
            this.productsBindingSource3.DataSource = this.techSupportDataSet1;
            // 
            // productsBindingSource4
            // 
            this.productsBindingSource4.DataMember = "Products";
            this.productsBindingSource4.DataSource = this.techSupportDataSet1;
            // 
            // fKIncidentsProductsBindingSource
            // 
            this.fKIncidentsProductsBindingSource.DataMember = "FK_Incidents_Products";
            this.fKIncidentsProductsBindingSource.DataSource = this.productsBindingSource4;
            // 
            // incidentsTableAdapter
            // 
            this.incidentsTableAdapter.ClearBeforeFill = true;
            // 
            // techSupportDataSet1BindingSource1
            // 
            this.techSupportDataSet1BindingSource1.DataSource = this.techSupportDataSet1;
            this.techSupportDataSet1BindingSource1.Position = 0;
            // 
            // productsBindingSource6
            // 
            this.productsBindingSource6.DataMember = "Products";
            this.productsBindingSource6.DataSource = this.techSupportDataSet1;
            // 
            // productsBindingSource7
            // 
            this.productsBindingSource7.DataMember = "Products";
            this.productsBindingSource7.DataSource = this.techSupportDataSet1;
            // 
            // productsBindingSource8
            // 
            this.productsBindingSource8.DataMember = "Products";
            this.productsBindingSource8.DataSource = this.techSupportDataSet1;
            // 
            // productsBindingSource9
            // 
            this.productsBindingSource9.DataMember = "Products";
            this.productsBindingSource9.DataSource = this.techSupportDataSet1;
            // 
            // productsBindingSource10
            // 
            this.productsBindingSource10.DataMember = "Products";
            this.productsBindingSource10.DataSource = this.techSupportDataSet1;
            // 
            // productsBindingSource11
            // 
            this.productsBindingSource11.DataMember = "Products";
            this.productsBindingSource11.DataSource = this.techSupportDataSet1;
            // 
            // techSupportDataSet1BindingSource2
            // 
            this.techSupportDataSet1BindingSource2.DataSource = this.techSupportDataSet1;
            this.techSupportDataSet1BindingSource2.Position = 0;
            // 
            // customersBindingSource
            // 
            this.customersBindingSource.DataMember = "Customers";
            this.customersBindingSource.DataSource = this.techSupportDataSet;
            // 
            // customersTableAdapter
            // 
            this.customersTableAdapter.ClearBeforeFill = true;
            // 
            // productsBindingSource5
            // 
            this.productsBindingSource5.DataMember = "Products";
            this.productsBindingSource5.DataSource = this.techSupportDataSet1;
            // 
            // techSupportDataSetBindingSource4
            // 
            this.techSupportDataSetBindingSource4.DataSource = this.techSupportDataSet;
            this.techSupportDataSetBindingSource4.Position = 0;
            // 
            // customersBindingSource2
            // 
            this.customersBindingSource2.DataMember = "Customers";
            this.customersBindingSource2.DataSource = this.techSupportDataSet;
            // 
            // productsBindingSource15
            // 
            this.productsBindingSource15.DataMember = "Products";
            this.productsBindingSource15.DataSource = this.techSupportDataSet;
            // 
            // productsBindingSource18
            // 
            this.productsBindingSource18.DataMember = "Products";
            this.productsBindingSource18.DataSource = this.techSupportDataSet4;
            // 
            // customersBindingSource4
            // 
            this.customersBindingSource4.DataMember = "Customers";
            this.customersBindingSource4.DataSource = this.techSupportDataSet4;
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.Location = new System.Drawing.Point(238, 38);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(83, 23);
            this.btnAddProduct.TabIndex = 10;
            this.btnAddProduct.Text = "Add Product";
            this.btnAddProduct.UseVisualStyleBackColor = true;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddCust_Click);
            // 
            // btnAddCustomer
            // 
            this.btnAddCustomer.Location = new System.Drawing.Point(238, 8);
            this.btnAddCustomer.Name = "btnAddCustomer";
            this.btnAddCustomer.Size = new System.Drawing.Size(83, 23);
            this.btnAddCustomer.TabIndex = 11;
            this.btnAddCustomer.Text = "Add Customer";
            this.btnAddCustomer.UseVisualStyleBackColor = true;
            this.btnAddCustomer.Click += new System.EventHandler(this.btnAddCustomer_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(333, 165);
            this.Controls.Add(this.btnAddCustomer);
            this.Controls.Add(this.btnAddProduct);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.txtRegDate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cboBoxProduct);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cboBoxCustomer);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Add Registration";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSetBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSetBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSetBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSet1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKIncidentsProductsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSet1BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSet1BindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.techSupportDataSetBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboBoxCustomer;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cboBoxProduct;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtRegDate;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.BindingSource techSupportDataSetBindingSource;
        private TechSupportDataSet techSupportDataSet;
        private System.Windows.Forms.BindingSource customersBindingSource1;
        private System.Windows.Forms.BindingSource techSupportDataSetBindingSource1;
        private System.Windows.Forms.BindingSource techSupportDataSetBindingSource2;
        private System.Windows.Forms.BindingSource productsBindingSource;
        private TechSupportDataSetTableAdapters.ProductsTableAdapter productsTableAdapter;
        private System.Windows.Forms.BindingSource techSupportDataSetBindingSource3;
        private System.Windows.Forms.BindingSource productsBindingSource1;
        private System.Windows.Forms.BindingSource techSupportDataSet1BindingSource;
        private TechSupportDataSet techSupportDataSet1;
        private System.Windows.Forms.BindingSource productsBindingSource2;
        private System.Windows.Forms.BindingSource productsBindingSource3;
        private System.Windows.Forms.BindingSource productsBindingSource4;
        private System.Windows.Forms.BindingSource fKIncidentsProductsBindingSource;
        private TechSupportDataSetTableAdapters.IncidentsTableAdapter incidentsTableAdapter;
        private System.Windows.Forms.BindingSource techSupportDataSet1BindingSource1;
        private System.Windows.Forms.BindingSource productsBindingSource6;
        private System.Windows.Forms.BindingSource productsBindingSource7;
        private System.Windows.Forms.BindingSource productsBindingSource8;
        private System.Windows.Forms.BindingSource productsBindingSource9;
        private System.Windows.Forms.BindingSource productsBindingSource10;
        private System.Windows.Forms.BindingSource productsBindingSource11;
        private System.Windows.Forms.BindingSource techSupportDataSet1BindingSource2;
        private System.Windows.Forms.BindingSource productsBindingSource12;
        private System.Windows.Forms.BindingSource customersBindingSource;
        private TechSupportDataSetTableAdapters.CustomersTableAdapter customersTableAdapter;
        private System.Windows.Forms.BindingSource productsBindingSource5;
        private System.Windows.Forms.BindingSource productsBindingSource14;
        private System.Windows.Forms.BindingSource productsBindingSource13;
        private System.Windows.Forms.BindingSource productsBindingSource15;
        private System.Windows.Forms.BindingSource techSupportDataSetBindingSource4;
        private System.Windows.Forms.BindingSource customersBindingSource2;
        private TechSupportDataSet techSupportDataSet2;
        private System.Windows.Forms.BindingSource productsBindingSource16;
        private System.Windows.Forms.BindingSource productsBindingSource17;
        private TechSupportDataSet techSupportDataSet3;
        private System.Windows.Forms.BindingSource customersBindingSource3;
        private TechSupportDataSet techSupportDataSet4;
        private System.Windows.Forms.BindingSource productsBindingSource18;
        private System.Windows.Forms.BindingSource customersBindingSource4;
        private System.Windows.Forms.BindingSource productsBindingSource19;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.Button btnAddCustomer;
    }
}

